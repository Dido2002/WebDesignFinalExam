    //Logic to solve the problem...
    //First create a massiv to store the elements

    let productStorage = [];
       

function printProducts(items) {
    html = '<table class="table w-75 text-center">';
    html += '<tr class="bg-info">';
    html += '<th >Category:</th>';
    html += '<th>Price:</th>';
    html += '</tr>';
    for (let i = 0; i < items.length; i++) {
        html += '<tr class="bg-secondary">';
        html += `<td>${items[i].category}</td><td>${items[i].price}</td>`;
        html += '</tr>';
    }
    html += '</table>';
    console.log(items);
    $('#items').html(html);
}
//Get the element data ...
function getProductsData() {
    $.ajax({
        url: 'http://blacatzacademy.com/api/products',
        type: 'GET',
        success: function (items) {
            productStorage = items;
            printProducts(productStorage);
        }
    });
}

$('#check').click(function () {
    let to = parseInt($('#to').val());
    let from = parseInt($('#from').val());
    
    let filteredItems = productStorage.filter(p => {
        if (from >= 0 && p.price < from) {
            return false;
        }
        if (to >= 0 && p.price > to) {
            return false;
        }
        return true;
    });

    printProducts(filteredItems);
});

$(function () {
    getProductsData();
});
//Execute the program

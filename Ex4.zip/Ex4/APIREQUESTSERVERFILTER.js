
//Logic to solve the problem

//First create masiv to store all the elements
let checkUser = [];

function presentUsers(Udata) {
    let html = '<table class="table">';
    html += '<tr class="bg-info">';
    html += '<th>Id</th>';
    html += '<th>Name</th>';
    html += '<th>Lastname</th>';
    html += '<th>Age</th>';
    html += '<th>Salary</th>';
    html += '</tr>';

    //The other way with the for loop...
    // for(let i = 0; i < checkUser.length; i++){

    // }

    //Create the table with the user data
    checkUser.forEach(val => {
        html += '<tr class="bg-secondary text-white">';
        html += `<td>${val.id}</td><td>${val.name}</td>`;
        html += `<td>${val.lastName}</td><td>${val.age}</td>`;
        html += `<td>${val.salary}$</td>`;
        html += '</tr>';
    });

    html += '</table>';
    $('#usersData').html(html);
}

//Get the userData from the source 
function showUserData() {
    $.ajax({
        url: 'https://blacatzacademy.com/api/users',
        type: 'GET',
        success: function (response) {
            checkUser = response;
            presentUsers(checkUser);
        }
    });
}

//Logic to find the entered userId...
$('#check').click(function () {
    let userNumber = $('#user-id').val();

    if (userNumber != null) {
        $.ajax({
            url: `https://blacatzacademy.com/api/users?id=${userNumber}`,
            type: 'GET',
            success: function (Udata) {
                checkUser = Udata;
                presentUsers(checkUser);
                console.log(checkUser);
            }
        });
    }
    if (userNumber <= 0) {
        alert('You have wrong input!');
        return;
    }
});

//Execute..
$(function () {
    showUserData();
});
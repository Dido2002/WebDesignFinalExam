const dropdown = document.querySelector(".dropdown");
const menu = document.querySelector(".menu");
dropdown.addEventListener("click",() => {
    dropdown.classList.toggle("active");
    menu.classList.toggle("active");

})
document.querySelectorAll(".links").forEach(n => n.addEventListener("click",() => {
    dropdown.classList.remove("active");
    menu.classList.remove("active");

}))